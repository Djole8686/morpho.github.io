
# Dinastije – mini sajt + QR kodovi

Detaljna uputstva za hostovanje i prilagođavanje.
